library(devtools)
remove.packages("TVMVP")
devtools::clean_dll()
build()
install()

# Example
setwd("C:/Users/erikl_xzy542i/Documents/Master_local/Thesis/TV-MVP/TVMVP")
# Load necessary libraries
library(MASS)        # For matrix operations
library(matrixcalc)  # For matrix calculations
library(glmnet)      # For lasso penalization
library(FactoMineR)  # For PCA
library(quadprog)    # For quadratic programming
library(forecast)    # For ARIMA comparison
library(zoo)         # For rolling operations
library(ggplot2)     # For visualization
library(TVMVP)
library(PerformanceAnalytics)


data("edhec")
head(edhec)
# edhec is a time series (xts) of hedge fund indexes
returns<- as.matrix(edhec)



# Select bandwidth using Silverman's rule of thumb or CV
bandwidth <- silverman(returns)

folds <- list(
  returns[1:58, ],    # Fold 1
  returns[59:118, ],   # Fold 2
  returns[119:176, ],  # Fold 3
  returns[177:236, ], # Fold 4
  returns[237:293, ]  # Fold 5
)
bandwidth <- cv_bandwidth(returns, folds, seq(0.1, 1.0, by=0.05), 10, epanechnikov_kernel)

# Perform Local PCA for all time points
local_pca_res <- localPCA(returns, bandwidth, 10)
summary(local_pca_res$factors)
cov(local_pca_res$factors)
m <- local_pca_res$m

# Global PCA
global_pca <- prcomp(returns, scale. = FALSE, center = TRUE)
global_factors <- global_pca$x[, 1:m]
global_loadings <- global_pca$rotation[, 1:m]

# Compute residuals
res <- residuals(local_pca_res$factors, local_pca_res$loadings, returns)

# Test if covariance is time invariant
hyptest1(
  local_factors = local_pca_res$factors,
  global_factors = global_factors,
  local_loadings = local_pca_res$loadings,
  global_loadings = global_loadings,
  residuals = res,
  kernel_func = epanechnikov_kernel
)

W <- 100

# Evaluate model on data to see if it is sensible to use:
forecast <- forecast_local_factor_model(returns, W, m, bandwidth)

covs <- realized_covariances(W, returns, res)
true_weights <- optimal_weights(W, local_pca_res$factors_list,
                                local_pca_res$loadings_list,
                                covs$realized_resid_covariances,
                                nrow(returns),
                                ncol(returns))
sharpes <- SR(W, returns, local_pca_res$loadings_list,
              local_pca_res$factors_list, true_weights,
              covs$realized_resid_covariances)

ev <- evaluate_forecasts(
  returns        = returns,
  forecasts      = forecast$forecasts,
  est_covariances = forecast$est_covariances,
  residual_covariances_pred = forecast$residual_covariances,
  weights_est    = forecast$optimal_weights,
  window_eval    = (W+1):T,
  realized_covariances       = covs$realized_covariances,
  realized_resid_covariances = covs$realized_resid_covariances,
  true_weights   = true_weights,
  realized_sharpes = sharpes
)
print(ev)

# If satisfactory, use this method in order to produce the minimum variance portfolio
mu <- compute_mean_returns(local_loadings = local_pca_res$loadings_list,
                           local_factors = local_pca_res$factors_list)

tvmvp <- minvar_portfolio(mu[200,],
                          compute_time_varying_cov(local_pca_res$loadings_list[[200]],
                                                   cov(local_pca_res$factors_list[[200]]),
                                                   covs$realized_resid_covariances[[200]]
                          ),
                          0.005)
plot_portfolio_weights(tvmvp$w_g, title = "Global Minimum Portfolio Weights")
plot_portfolio_weights(tvmvp$w_p, title = "Target Minimum Portfolio Weights")











### testing some new functions, data-driven bandwidth

compute_optimal_weights <- function(returns_train) {
  # 1) Estimate the covariance matrix
  cov_mat <- cov(returns_train)  # p x p

  # 2) Invert the covariance matrix
  inv_cov <- solve(cov_mat)

  # 3) Min-var weights: w ~ inv_cov * 1  subject to sum(w)=1
  ones <- rep(1, ncol(returns_train))
  w_unnorm <- inv_cov %*% ones
  w <- as.numeric(w_unnorm / sum(w_unnorm))  # convert from vector class "matrix" to numeric

  return(w)  # p-dimensional numeric vector
}

realized_sharpe <- function(w, test_data) {
  # 1) Each row in test_data is a time point, columns are assets
  #    So portfolio return at time t is test_data[t, ] %*% w
  port_ret <- test_data %*% w  # dimension T_test x 1

  # 2) Basic Sharpe ratio = mean / stdev of portfolio returns
  sr <- mean(port_ret) / sd(port_ret)
  return(sr)
}

compute_residuals <- function(local_factors, loadings_list, returns) {
  # For each row t, returns[t, ] is 1 x p
  # local_factors[t, ] is 1 x m, loadings_list[[t]] is p x m?
  # Then modelled return = local_factors[t, ] %*% t(loadings_list[[t]]) => 1 x p
  # residual = returns[t, ] - modelled => 1 x p

  Tn <- nrow(returns)
  p <- ncol(returns)
  res <- matrix(NA, Tn, p)
  for (tt in 1:Tn) {
    # if loadings_list[[tt]] is p x m, and local_factors[tt, ] is 1 x m
    # then local_factors[tt, ] %*% t(loadings_list[[tt]]) => 1 x p
    modeled <- local_factors[tt, , drop=FALSE] %*% t(loadings_list[[tt]])
    res[tt, ] <- returns[tt, ] - modeled
  }
  res
}



cv_bandwidth <- function(returns, folds, candidate_h, max_factors, kernel_func) {
  k <- length(folds)  # number of CV folds
  scores <- numeric(length(candidate_h))

  for (h_i in seq_along(candidate_h)) {
    h_val <- candidate_h[h_i]
    sr_sum <- 0
    # For each test fold j=2..k, train on the preceding folds 1..(j-1)
    for (j in 2:k) {
      train_data <- do.call(rbind, folds[1:(j-1)])
      test_data  <- folds[[j]]

      # 1) Fit local PCA on train_data -> local factor model
      local_pca_train <- localPCA(train_data, bandwidth = h_val,
                                  max_factors = max_factors, kernel_func = kernel_func)

      # 2) Construct factor-based covariance. For example:
      #    a) Covariance of local factors
      factor_cov <- cov(local_pca_train$factors)
      #    b) Estimate residual covariance (some approach)
      #       Here, we do a naive sample covariance of residuals
      #       ignoring local variations, just as a simple placeholder:
      res <- compute_residuals(
        local_factors = local_pca_train$factors,
        loadings_list = local_pca_train$loadings,
        returns       = train_data
      )
      residual_cov <- cov(res)

      #    c) Combine them: Sigma_hat = L factor_cov L^T + residual_cov
      #       local_pca_train$loadings[[t]] is the local loadings for each time t,
      #       but if we just do an average? Or pick a typical t?
      #       There's a question of how exactly you want to get a single covariance from local PCA.

      # average_loadings => p x m
      load_sum <- matrix(0, nrow=p, ncol=m)
      valid_count <- 0
      for (tt in 1:nrow(train_data)) {
        if (!anyNA(local_pca_train$loadings[[tt]])) {
          load_sum <- load_sum + local_pca_train$loadings[[tt]]
          valid_count <- valid_count + 1
        }
      }
      avg_loadings <- load_sum / valid_count

      Sigma_hat <- avg_loadings %*% factor_cov %*% t(avg_loadings) + residual_cov

      # 3) Get min-var weights from Sigma_hat
      inv_cov <- solve(Sigma_hat)
      ones <- rep(1, nrow(Sigma_hat))
      w_unnorm <- inv_cov %*% ones
      w_hat <- as.numeric(w_unnorm / sum(w_unnorm))

      # 4) Evaluate performance on test_data
      sr_test <- realized_sharpe(w_hat, test_data)
      sr_sum <- sr_sum + sr_test
    }
    scores[h_i] <- sr_sum
  }

  # pick h that yields the best total performance
  best_idx <- which.max(scores)
  h_cv <- candidate_h[best_idx]
  return(h_cv)
}

folds <- list(
  returns[1:58, ],    # Fold 1
  returns[59:118, ],   # Fold 2
  returns[119:176, ],  # Fold 3
  returns[177:236, ], # Fold 4
  returns[237:293, ]  # Fold 5
)


cv_bandwidth(returns, folds, seq(0.1, 1.0, by=0.05), 10, epanechnikov_kernel)
